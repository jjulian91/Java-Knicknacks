
public class gamePlay {



    public static void main(String[] args){

    }

    public static void Start() {
        int playerCount=0;
        int compCount = 0;

        System.out.println("Current Score is: \n" +
                "Player: "+playerCount+"  Computer: "+compCount);
        System.out.println("Player rolls first!");
        playerRoll();

        System.out.println("Good Game!");

        }
    public static int playerRoll(){
        PairOfDice dice;
        dice = new PairOfDice();

        int Pdie1= 0;
        int Pdie2 = 0;
        int playerTot=0;
        while(Pdie1 != 1 && Pdie2 !=1){
            dice.roll();
            Pdie1=dice.getDie1();
            Pdie2 =dice.getDie2();
        playerTot += dice.getTotal();
        System.out.println(Pdie1+" "+Pdie2);
        System.out.println(playerTot);
        }


        System.out.println(playerTot);
        return playerTot;
    }
    public static int computerRoll(){
        PairOfDice compdice;
        compdice = new PairOfDice();
        compdice.roll();
        compdice.getDie1();
        compdice.getDie2();
        int compTot=compdice.getTotal();

        System.out.println(compTot);
        return compTot;
    }
    }
