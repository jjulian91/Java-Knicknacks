import java.util.Scanner;


public class Hog {
    private static String Valid = "Y";

    public static void main(String[] args) {
        gamePlay.Start();


        System.out.println("Would you like to play again" +
                "\nenter Y for Yes or any other key to exit");
        Scanner userInput = new Scanner(System.in);
        String response = userInput.nextLine();
        char ans = response.charAt(0);
        String Answer = Character.toString(ans);

        while (Answer.compareToIgnoreCase(Valid)!=0) {
           gamePlay.Start();
            System.out.println("Would you like to play again" +
                    "\nenter Y for Yes or any other key to exit");
            response = userInput.nextLine();
            ans = response.charAt(0);
            Answer = Character.toString(ans);


        }


    }
}
