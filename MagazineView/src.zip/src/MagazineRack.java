
import java.util.Scanner;
import java.io.*;

public class MagazineRack
{


    //----------------------------------------------------------------
    //  Creates a MagazineList object, adds user input, asks user if they would
    //  like to remove any titles, prints list, and saves to "mag.dat" file
    //----------------------------------------------------------------
    public static void main(String[] args) throws IOException
    {

        FileWriter fwriter;
        BufferedWriter bufferW;
        PrintWriter printer;
        String response;
        char ans;
        String file = "mags.dat";
        Scanner scan = new Scanner(System.in);
        MagazineList rack = new MagazineList();


        try {
            Scanner in = new Scanner(new FileReader(file));
            System.out.println("Here is the list of current magazines: ");
            while (in.hasNext())    {
                String listener = in.nextLine();
                Magazine inputmag = new Magazine(listener);
                rack.insert(inputmag);
                System.out.println(listener);
                }
            in.close();
             }
        catch (FileNotFoundException e)
            {
                System.out.println("File not found... Creating File");
                fwriter = new FileWriter(file);
                System.out.println("File Created");
                bufferW = new BufferedWriter(fwriter);
                printer = new PrintWriter(bufferW);
                printer.close();
            }
        finally {
            System.out.print("Would You like to enter a title (y/n): ");
            response = scan.nextLine();
            ans = Character.toLowerCase(response.charAt(0));
            while (ans == 'y') {
                System.out.print("Please enter a title: ");
                String title = scan.nextLine();
                Magazine tempTitle = new Magazine(title);
                rack.insert(tempTitle);
                System.out.print("Would You like to enter a title (y/n): ");
                response = scan.nextLine();
                ans = Character.toLowerCase(response.charAt(0));
            }
        }
        System.out.print("Would You like to Remove a title (y/n): ");
        response = scan.nextLine();
        ans = Character.toLowerCase(response.charAt(0));


        while (ans == 'y') {
            System.out.println("Here are your magazines: ");
            System.out.println(rack);
            System.out.print("Please enter a title to remove: ");
            String title = scan.nextLine();
            Magazine tempTitle = new Magazine(title);
            rack.delete(tempTitle);
            System.out.print("Would You like to remove another title (y/n): ");
            response = scan.nextLine();
            ans = Character.toLowerCase(response.charAt(0));
        }

        System.out.println("Here are your magazines: ");
        System.out.println(rack);


        fwriter = new FileWriter(file);
        bufferW = new BufferedWriter(fwriter);
        printer = new PrintWriter(bufferW);
        printer.write(rack.toString());
        printer.close();

    }
    }




